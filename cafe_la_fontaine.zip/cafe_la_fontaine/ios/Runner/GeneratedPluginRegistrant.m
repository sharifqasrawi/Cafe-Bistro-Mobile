//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <google_maps_flutter/GoogleMapsPlugin.h>
#import <permission/PermissionPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FLTGoogleMapsPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTGoogleMapsPlugin"]];
  [PermissionPlugin registerWithRegistrar:[registry registrarForPlugin:@"PermissionPlugin"]];
}

@end
