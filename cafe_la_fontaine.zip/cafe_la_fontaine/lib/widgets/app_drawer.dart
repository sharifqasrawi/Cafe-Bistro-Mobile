import 'package:flutter/material.dart';

import '../screens/contactus_screen.dart';
import '../screens/menu_screen.dart';

class AppDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Container(
        child: ListView(
          children: <Widget>[
            AppBar(
              title: Text('Cafe La Fontaine'),
              automaticallyImplyLeading: false,
            ),
            Divider(),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('Home'),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushReplacementNamed('/');
              },
            ),
            Divider(),
            ListTile(
              leading: const Icon(Icons.restaurant_menu),
              title: const Text('Menu'),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushNamed(MenuScreen.routeName);
              },
            ),
            Divider(),
            ListTile(
              leading: const Icon(Icons.message),
              title: const Text('Contact us'),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushNamed(ContactUsScreen.routeName);
              },
            ),
          ],
        ),
      ),
    );
  }
}
